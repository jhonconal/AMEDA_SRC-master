/**************************************************************
**This is available in all editors.
**Copyright(c)2016 ebulent(shenzhen)Co.,LTD. All Right Reserved.
**Contact: http://www.ebulent.com.cn/
**Author: qain.yang
**Postion: Softwere engineer
**email:qian.yang@ebulent.com.cn jhonconal@outlook.com
**This app sourcecode are for ameda test
**
***************************************************************/
#include "amerdathread.h"

AmerdaThread::AmerdaThread(QObject*parent):
    QThread(parent)
{
    pressure_val  =0.0;
    mmHg_val = 0.0;
    dlv015_fd =0;
    fd = open("/dev/DLV_015A",O_RDWR);
    if(fd <0)
    {
        perror("open dlv_015a device dailed.");
        close(fd);
    }
    //该值传给AmedaWidget判断串口是否连接
    dlv015_fd=fd;
}

AmerdaThread::~AmerdaThread()
{
    this->finished();
    this->destroyed();
    this->setTerminationEnabled(true);
}

void AmerdaThread::dlv015aSensorDevice()
{
    double mmHg = 0.0;
    if(read(fd,rbuf,4) !=4)
    {
//        perror("read BUF failed.");
        close(fd);
        exit(1);
    }
    else
    {
        memset(dlv015a_pressure,0,sizeof(dlv015a_pressure));
        memcpy(dlv015a_pressure,rbuf,2);
        pressure_val = (( (dlv015a_pressure[0] & 0x3f) << 8) |dlv015a_pressure[1]);
//        qDebug()<<" pressure_val ="<< pressure_val ;
        mmHg = (((pressure_val - 1638) * 1.25 * 15) / 16384) * 51.715;
//        qDebug()<<"mmHg_val ="<<mmHg;
        emit dlv015aSensorSignal(mmHg);
//        SLEEP(20);
    }
}

void AmerdaThread::SLEEP(int ms)
{
    QTime dieTime = QTime::currentTime().addMSecs(ms);
    while ( QTime::currentTime() < dieTime )
    {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
    }
}

//线程采集信息
void AmerdaThread::run()
{
    while(1)
    {
        dlv015aSensorDevice();
    }
}
