#include "atmindexwidget.h"
#include "ui_atmindexwidget.h"

AtmIndexWidget::AtmIndexWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AtmIndexWidget)
{
    ui->setupUi(this);
    imageNameList<<"1.jpg"<<"2.jpg"<<"3.jpg"<<"4.jpg"<<"5.jpg";
    this->setStyleSheet("background-image: url(:/src/images/1.jpg)");
    init();
    //    setWindowFlags(Qt::FramelessWindowHint);//无边框
}

AtmIndexWidget::~AtmIndexWidget()
{
    delete ui;
}

void AtmIndexWidget::init()
{
    reCheckGuide =true;
    index =0;
    MaxIndex= 4;
}

void AtmIndexWidget::on_PreButton_clicked()
{
    ui->NextButton->setText("Next >> ");
    if (index ==0)
    {
        index =0;
    }
    else if(index>0&&index<=MaxIndex)
    {
        index--;
    }
    //       qDebug()<<"image: "<<imageNameList.at(index);
    ui->widget->setStyleSheet(QString("background-image: url(:/src/images/%1);").arg(imageNameList.at(index)));
    //       qDebug()<<"index="<<index;
}

void AtmIndexWidget::on_NextButton_clicked()
{
    if(ui->NextButton->text()==" Close >> ")
    {
        index =0;
        ui->widget->setStyleSheet(QString("background-image: url(:/src/images/%1);").arg(imageNameList.at(index)));
        QMessageBox message(QMessageBox::Question, "Shutt Off The Guide ?", "\nDo you want to shutt off  this guide next time ?", QMessageBox::Yes | QMessageBox::No, NULL);
        if(message.exec() == QMessageBox::Yes)
        {
            qDebug()<<"Check status: YES";
            reCheckGuide = false;
        }
        else
        {
            qDebug()<<"Check status: No";
            reCheckGuide = true;
        }
        emit reCheckGuideSignal(reCheckGuide);
        emit closeWidgetSignal();
    }
    if(index>=MaxIndex-1)
    {
        index=MaxIndex;
        //            ui->PreButton->setVisible(false);
        ui->NextButton->setText(" Close >> ");
    }
    else if(index>=0&&index<MaxIndex)
    {
        index++;
    }
    //    qDebug()<<"image: "<<imageNameList.at(index);
    ui->widget->setStyleSheet(QString("background-image: url(:/src/images/%1);").arg(imageNameList.at(index)));
    //      qDebug()<<"index="<<index;
}
