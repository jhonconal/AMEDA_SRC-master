#include "guidewidget.h"
#include "ui_guidewidget.h"

GuideWidget::GuideWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GuideWidget)
{
    ui->setupUi(this);
}

GuideWidget::~GuideWidget()
{
    delete ui;
}
