#ifndef GUIDEWIDGET_H
#define GUIDEWIDGET_H

#include <QWidget>

namespace Ui {
class GuideWidget;
}

class GuideWidget : public QWidget
{
    Q_OBJECT

public:
    explicit GuideWidget(QWidget *parent = 0);
    ~GuideWidget();

private:
    Ui::GuideWidget *ui;
};

#endif // GUIDEWIDGET_H
