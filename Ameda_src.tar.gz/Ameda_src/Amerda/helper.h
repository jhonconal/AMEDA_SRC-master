/**************************************************************
**This is available in all editors.
**Copyright(c)2016 ebulent(shenzhen)Co.,LTD. All Right Reserved.
**Contact: http://www.ebulent.com.cn/
**Author: qain.yang
**Postion: Softwere engineer
**email:qian.yang@ebulent.com.cn jhonconal@outlook.com
**This app sourcecode are for ameda test
**
***************************************************************/
#ifndef HELPER_H
#define HELPER_H

#include<QObject>
#include<QTranslator>
#include<QDesktopWidget>
#include<QtGui>
#include<QtCore>
#include<QString>
#include <QFile>
#include <QDir>
#include <QMap>
#include <QVector>
#include<QByteArray>
#include<QProcess>
#ifdef Q_OS_LINUX
#include<QSound>
#endif
#include<QApplication>
class Helper : public QObject
{
    Q_OBJECT
public:
    explicit Helper(QObject *parent = 0);
    double Hextodec(char *hex);
    //设置编码为UTF8
    void SetUTF8Code();
    void SetGB232Code();
    void SetChinese();
    /**
     * @brief Char2String
     * @param ch
     * @return  CAHR* 转String
     */
    QString Char2String(char *ch);
    /**
     * @brief String2Char
     * @param str
     * @return 字符串转CHAR
     */
    char *String2Char(QString str);
    //播放声音
    void PlaySound(QString soundName);
    //设置系统日期时间
    void SetSystemDateTime(int year,int month,int day,int hour,int min,int sec);
    //设置皮肤颜色
    //设置皮肤样式
    void SetStyle(const QString &styleName);
    /**
     * @brief WriteSaveFile
     * @param text 写入文件的内容
     * @param filename  创建文件名
     * @return true 成功返回真
     */
    bool WriteSaveFile(const QString &filename ,QString text);
    /**
     * @brief readFileContentToDouble
     * @return
     */
    double readFileContentToDouble(const QString &filename);
    bool     writeDoubleContentToFile(QString text);
    /**
     * @brief SLEEP
     * @param ms  睡眠时间
     * 睡眠函数
     */
    void SLEEP(int ms);
    /**
     * @brief getMaxOrMinValue
     * @param value
     * @param MaxOrMin
     * @return   获取QVector最大最小值
     */
    double getMaxOrMinValue(QVector<double>vector,bool MaxOrMin);

signals:

public slots:

};

#endif // HELPER_H
