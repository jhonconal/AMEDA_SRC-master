/**************************************************************
**This is available in all editors.
**Copyright(c)2016 ebulent(shenzhen)Co.,LTD. All Right Reserved.
**Contact: http://www.ebulent.com.cn/
**Author: qain.yang
**Postion: Softwere engineer
**email:qian.yang@ebulent.com.cn jhonconal@outlook.com
**This app sourcecode are for ameda test
**
***************************************************************/
#include "amerdawidget.h"
#include <QApplication>
#include <QTextCodec>
#include <stdio.h>
#include "helper.h"
#include <QLabel>
#include <QMovie>
#include <QSplashScreen>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Helper *help = new Helper();
#if QT_VERSION < QT_VERSION_CHECK(5, 0, 0)//判断QT版本是否大于5.0
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));       //支持Tr中文
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));//支持中文文件名显示
#else
    QFont font;
//    font.setFamily(("kaiti.TTF"));
    font.setFamily(":/src/fonts/Helvetica.ttf");
    font.setBold(false);
    a.setFont(font);
    help->SetChinese();
#endif
    QMovie *movie;
    movie = new QMovie(":/src/ameda.gif");
    QLabel *label= new QLabel("",0);
    label->setGeometry(0,0,1024,768);
    label->setMovie(movie);
    label->setScaledContents(true);
    movie->start();
    label->show();
    help->SLEEP(5000);

    AmerdaWidget w;
    w.show();

    label->close();
    return a.exec();
}
