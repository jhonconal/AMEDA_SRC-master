/**************************************************************
**This is available in all editors.
**Copyright(c)2016 ebulent(shenzhen)Co.,LTD. All Right Reserved.
**Contact: http://www.ebulent.com.cn/
**Author: qain.yang
**Postion: Softwere engineer
**email:qian.yang@ebulent.com.cn jhonconal@outlook.com
**This app sourcecode are for ameda test
**
***************************************************************/
#ifndef AMERDATHREAD_H
#define AMERDATHREAD_H
// DLV_015A  设备所需要头文件
#ifdef Q_OS_LINUX
#include <linux/i2c-dev.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <QtCore>
#include <QtGui>

#include <QObject>
#include <QThread>
#include <QDebug>
class AmerdaThread : public QThread
{
    Q_OBJECT
public:
    explicit AmerdaThread(QObject *parent=0);
    ~AmerdaThread();

    /**
     * @brief dlv015aSensorDevice
     * @return   读取dlv015a设备数据
     */
    void dlv015aSensorDevice();
    /**
     * @brief SLEEP
     * @param ms  睡眠时间
     * 睡眠函数
     */
    void SLEEP(int ms);
signals:
    void dlv015aSensorSignal(double mmHg);
    void dlv015aSensorSignal(double time,double mmHg);

protected:
    void run();

private:
    int fd;
    double pressure_val ,
           mmHg_val;
    char   rbuf[10],dlv015a_pressure[2];
public:
    int    dlv015_fd;
};

#endif // AMERDATHREAD_H
