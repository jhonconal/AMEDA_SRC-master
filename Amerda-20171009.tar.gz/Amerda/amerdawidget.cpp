/**************************************************************
**This is available in all editors.
**Copyright(c)2016 ebulent(shenzhen)Co.,LTD. All Right Reserved.
**Contact: http://www.ebulent.com.cn/
**Author: qain.yang
**Postion: Softwere engineer
**email:qian.yang@ebulent.com.cn jhonconal@outlook.com
**This app sourcecode are for ameda test
**
***************************************************************/
#include "amerdawidget.h"
#include "ui_amerdawidget.h"
#if QT_VERSION > QT_VERSION_CHECK(5, 0, 0)
#include <QStandardPaths>
#else
#endif
#include "qstring.h"
AmerdaWidget::AmerdaWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AmerdaWidget)
{
    ui->setupUi(this);
    init();//初始化参数
    help = new Helper();
    //读取当地大气压值
    Atmospheric = help->readFileContentToDouble("/data/atm.txt");
    //qDebug()<<"Read======"<<Atmospheric;
    updateTimer->setInterval(1);
    systemTimer->setInterval(1000);
    amerda =new AmerdaThread(this);
    //updateTimer->start();
    amerda->start();
    connect(systemTimer,SIGNAL(timeout()),this,SLOT(SystemTimeSlot()));
    systemTimer->start(0);
    qDebug()<<"dlv015_fd="<<amerda->dlv015_fd;
    if(amerda->dlv015_fd<=0)
    {
        QMessageBox::critical(NULL,"DLV015 Sersor Connect Status ","\nDLV015 sensor failed to connect .");
    }
    //检测U盘
    int result = UDiskDetection();
    if(result == 0)
    {
        qDebug()<<"UDisk mounted,founded the [Ameda_data] floder.";
        //        QMessageBox::about(NULL,"UDisk Detection","UDisk mounted,and found [Ameda_data] floder.");
    }
    else if (result == 1)
    {
        qDebug()<<"UDisk mounted,create  the  [Ameda_data] floder.";
        //        QMessageBox::about(NULL,"UDisk Detection","UDisk mounted,and create [Ameda_data] floder.");
    }
    else
    {
        qDebug()<<"UDisk do not mounted.";
        //        QMessageBox::about(NULL,"UDisk Detection","UDisk do not mounted.");
    }
    ui->LogButton->setVisible(false);
    this->resize(width,height);
    setWindowFlags(Qt::FramelessWindowHint);//无边框
}

AmerdaWidget::~AmerdaWidget()
{
    if(amerda->isRunning())
    {
        amerda->~AmerdaThread();
    }
    delete ui;
}

void AmerdaWidget::init()
{
    help = new Helper(this);
    setLanguage("English");
    initAmerdaCruve();
    initParametersValue();
    desktop = QApplication::desktop();
    width  = desktop->screenGeometry().width();
    height  = desktop->screenGeometry().height();
    edit = new QTextEdit();
    edit->setReadOnly(true);
    updateTimer = new QTimer(this);
    systemTimer = new QTimer(this);
    sampleTimer = new QTimer(this);

    ui->comboBox->setView(new QListView);
    ui->comboBox->setStyleSheet("QComboBox{min-height: 50px;  background-color: rgb(220,10,75);\
                                color: rgb(255, 255, 255); border-radius: 3px; padding: 1px 18px 1px 3px;} "
                                "QComboBox::drop-down{width: 10px;background-color: rgb(100,100,100,150) }"
                                "QComboBox QAbstractItemView{background-color: rgb(55,55,55);color:rgb(255,255,255);font-size:16px;}"
                                "QComboBox QAbstractItemView:item{min-height: 50px; }");
    ui->comboBox_2->setView(new QListView);
    ui->comboBox_2->setStyleSheet("QComboBox{min-height: 50px;  background-color: rgb(220,10,75);\
                            color: rgb(255, 255, 255); border-radius: 3px; padding: 1px 18px 1px 3px;} "
                            "QComboBox::drop-down{width: 10px;background-color: rgb(100,100,100,150) }"
                            "QComboBox QAbstractItemView{background-color: rgb(55,55,55);color:rgb(255,255,255);font-size:16px;}"
                            "QComboBox QAbstractItemView:item{min-height: 50px; }");
    ui->comboBox_3->setView(new QListView);
    ui->comboBox_3->setStyleSheet("QComboBox{min-height: 50px;  background-color: rgb(220,10,75);\
                            color: rgb(255, 255, 255); border-radius: 3px; padding: 1px 18px 1px 3px;} "
                            "QComboBox::drop-down{width: 10px;background-color: rgb(100,100,100,150) }"
                            "QComboBox QAbstractItemView{background-color: rgb(55,55,55);color:rgb(255,255,255);font-size:16px;}"
                            "QComboBox QAbstractItemView:item{min-height: 50px; }");
    ui->comboBox_4->setView(new QListView);
    ui->comboBox_4->setStyleSheet("QComboBox{min-height: 50px;  background-color: rgb(220,10,75);\
                            color: rgb(255, 255, 255); border-radius: 3px; padding: 1px 18px 1px 3px;} "
                            "QComboBox::drop-down{width: 10px;background-color: rgb(100,100,100,150) }"
                            "QComboBox QAbstractItemView{background-color: rgb(55,55,55);color:rgb(255,255,255);font-size:16px;}"
                            "QComboBox QAbstractItemView:item{min-height: 50px; }");
}
/**
 * @brief AmerdaWidget::setLanguage
 * @param language
 * @return
 * 程序语言设置
 */
bool AmerdaWidget::setLanguage(QString language)
{
    if(language == "English")
    {
        ui->Label_2->setText("Testing Choices:");
        ui->Label_3->setText("Standard Ranges:");
        ui->SpeedAreaLabel->setText("Speed Range");
        ui->PressureAreaLabel->setText("Suction Range");
        ui->Label_5->setText("Parameters:");
        ui->TestButton->setText("Start");
        ui->MaxValueLabel->setText("Max Value (mmHg)");
        ui->MinValueLabel->setText("Min Value (mmHg)");
        ui->DetaPressureLabel->setText("△P (mmHg)");
        ui->FrequenceLabel->setText("CPM (cycle/min)");
        ui->LogButton->setText("Log Preview");
        ui->SaveButton->setText("Save");
        return true;
    }
    else
    {
        ui->Label_2->setText("测试选项:");
        ui->Label_3->setText("标准区间:");
        ui->SpeedAreaLabel->setText("速度范围:");
        ui->PressureAreaLabel->setText("压力范围:");
        ui->Label_5->setText("参数输出:");
        ui->TestButton->setText("启动");
        ui->MaxValueLabel->setText("最大值(mmHg)");
        ui->MinValueLabel->setText("最小值(mmHg)");
        ui->FrequenceLabel->setText("周期/频率");
        ui->DetaPressureLabel->setText("压差 (mmHg)");
        ui->LogButton->setText("日志预览");
        ui->SaveButton->setText("保存");
        return false;
    }
    return false;
}
/**
 * @brief AmerdaWidget::initParametersValue
 * 参数值初始化
 */
void AmerdaWidget::initParametersValue()
{
    this->Max = 0;
    this->Min = 0;
    this->CPM = 0;
    this->TriangleP = 0;
    cycleDelay = 0;
    isEnglish = true;
    isPreview = true;
    isStopTesting = false;
    isSingal = true;//判断是否为单双奶瓶
    isReGuide = true;//Need the Guide
    sampling = true;
    onceDeal = false;
    standardLine = -1;//
    sampleAVG = 0;
    sampleMax = 0;
    sampleMin  = 0;
    sampleSum = 0;
    UDISK_STATUS = -1;
    UpperLine = LowerLine =755.0;
    index = 0;
}
/**
 * @brief AmerdaWidget::initAmerdaCruve
 * 压力曲线初始化
 */
void AmerdaWidget::initAmerdaCruve()
{
    QPen pen,pen2,pen3;
    QFont font,font2,font3;
    font.setBold(true);
    font2.setBold(true);
    font3.setBold(true);
    //=============
    font.setPointSize(15);
    font2.setPointSize(20);
    font3.setPointSize(20);
    //=============
    pen.setWidth(2);
    pen2.setWidth(2);
    pen3.setWidth(2);
    //=============
    pen.setColor(Qt::black);
    //pen2.setColor(QColor(255, 0, 127));
    pen2.setColor(Qt::red);
    pen3.setColor(Qt::green);
    //ui->qCustomPlot->setBackground(QBrush(QColor(45,45,45)));
    ui->qCustomPlot->legend->setBrush(QColor(255, 255, 255, 10));//透明背景
    ui->qCustomPlot->legend->setVisible(true);
    ui->qCustomPlot->legend->setTextColor(Qt::blue);
    ui->qCustomPlot->addGraph();
    ui->qCustomPlot->graph(0)->setPen(pen);
    //添加 Upper Lower 刻度线
    //===================================================================
    ui->qCustomPlot->addGraph();
    ui->qCustomPlot->graph(1)->setPen(pen2);
    //    ui->qCustomPlot->legend->removeItem(ui->qCustomPlot->legend->itemCount()-1);
    ui->qCustomPlot->addGraph();
    ui->qCustomPlot->graph(2)->setPen(pen2);
    //    ui->qCustomPlot->legend->removeItem(ui->qCustomPlot->legend->itemCount()-1);
    ui->qCustomPlot->addGraph();
    ui->qCustomPlot->graph(3)->setPen(pen3);
    //ui->qCustomPlot->legend->removeItem(ui->qCustomPlot->legend->itemCount()-1);
    //===================================================================
    ui->qCustomPlot->graph()->setAntialiasedFill(true);
    if(setLanguage("English"))
    {
        ui->qCustomPlot->graph(0)->setName("Suction Cruve");
        ui->qCustomPlot->graph(1)->setName("Max Suction");
        ui->qCustomPlot->graph(2)->setName("Min  Suction");
        ui->qCustomPlot->graph(3)->setName("Local Atmospheric");
    }
    else
    {
        ui->qCustomPlot->graph(0)->setName("吸力曲线");
        ui->qCustomPlot->graph(1)->setName("波峰吸力");
        ui->qCustomPlot->graph(2)->setName("波谷吸力");
        ui->qCustomPlot->graph(3)->setName("本地气压");
    }

    ui->qCustomPlot->axisRect()->setupFullAxesBox();
    //  ui->qCustomPlot->plotLayout()->insertRow(0);
    //  ui->qCustomPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->qCustomPlot, "Pressure Cruve"));
    ui->qCustomPlot->graph(0)->setLineStyle((QCPGraph::LineStyle)(1));
    ui->qCustomPlot->graph(0)->setScatterStyle(QCPScatterStyle((QCPScatterStyle::ScatterShape)(0)));
    ui->qCustomPlot->graph(1)->setScatterStyle(QCPScatterStyle((QCPScatterStyle::ScatterShape)(4)));
    ui->qCustomPlot->graph(2)->setScatterStyle(QCPScatterStyle((QCPScatterStyle::ScatterShape)(4)));
    //绘制y轴信息
    ui->qCustomPlot->yAxis->setLabelPadding(0);
    ui->qCustomPlot->yAxis->setTickLabelFont(font);
    ui->qCustomPlot->yAxis->setLabelFont(font2);
    ui->qCustomPlot->yAxis->setAutoTickStep(false);
    ui->qCustomPlot->yAxis->setRangeReversed(false);
    //    ui->qCustomPlot->yAxis->setLabelColor("#FF007F");
    ui->qCustomPlot->yAxis->setLabelColor(Qt::red);
    ui->qCustomPlot->yAxis->setRange(400,800);
    ui->qCustomPlot->yAxis->setTickStep(50);
    ui->qCustomPlot->yAxis->setLabel("(Pressure/mmHg)");
    //    ui->qCustomPlot->yAxis->setLabel("(pressure/Mpa)");
    ui->qCustomPlot->yAxis->setTickLabelRotation(22.5);//标签翻转角度
    //绘制y2轴信息
    ui->qCustomPlot->yAxis2->setAutoTickStep(false);
    ui->qCustomPlot->yAxis2->setRangeReversed(false);
    ui->qCustomPlot->yAxis2->setRange(400,800);
    ui->qCustomPlot->yAxis2->setTickStep(50);
    //绘制x轴信息
    ui->qCustomPlot->xAxis->setTickLabelFont(font);
    ui->qCustomPlot->xAxis->setLabelFont(font2);
    ui->qCustomPlot->xAxis->setAutoTickStep(false);
    ui->qCustomPlot->xAxis->setTickStep(1);//间隔1S
    //    ui->qCustomPlot->xAxis->setLabelColor("#FF007F");
    ui->qCustomPlot->xAxis->setLabelColor(Qt::red);
    ui->qCustomPlot->xAxis->setLabel("(Time/s)");
    //    ui->qCustomPlot->xAxis->setTickLabelRotation(12.5);
    ui->qCustomPlot->xAxis->setLabelPadding(-3);
    ui->qCustomPlot->xAxis->setTickLabelType(QCPAxis::ltDateTime);
    ui->qCustomPlot->xAxis->setDateTimeFormat("mm:ss");
    //ui->qCustomPlot->xAxis->setDateTimeFormat("hh:mm:ss");

}

/**
 * @brief AmerdaWidget::RealTimeDataSlot
 * 实时yValue
 */
void AmerdaWidget::RealTimeDataSlot()
{
    QPen pen;
    pen.setWidth(2);
    QTime time;
    time = QTime::currentTime();
    //获取x轴坐标时间值
    double  key = QDateTime::currentDateTime().toMSecsSinceEpoch()/1000.0; //seconds since 1970-01-01T00:00:00 UTC
    xAxisKey =key;
    //========================================================
    if(sampling)
    {
        double mmHg = yAxisValue;
        sampleVector.insert(index,mmHg);//
    }
    else
    {
        if(sampling==false&&onceDeal==true)
        {
            getSampleData(sampleVector);
            standardLine = (sampleMax+sampleAVG)/2;
            qDebug()<<"standardLine: "<<standardLine;
        }
        onceDeal = false;//disable re-sample
    }
#if 0
    //=======================实时数据处理===========================
    if(standardLine>0)
    {
        if(yAxisValue > standardLine)
        {//处理极大值区域
            MaxAreaPoints =0;
            if(MinVector.size()!=0)
            {
                //处理
                getMinValueIndex(MinVector);//get Min and MinIndex;
                ui->MinValueLineEdit->setText(QString::number(Min,'f',3)+ " mmHg");

#if 0
                TIME2 = MinHash.value((int)Min)-TIME2;
                //                qDebug()<<"周期内极大值:"<<Max ;
                ui->FrequenceLineEdit->setText(QString::number(60/TIME2,'f',3)+ " cycle/min");//CPM
                TIME2 = MinHash.value((int)Min);
#endif
                MinVector.clear();//处理清空极小值区域容器
                MinHash.clear();
                //qDebug()<<"周期内极小值: "<<Min;
            }
            else
            {//
                ;//如果极小值容器为空不做任何处理
            }
            MaxVector.append(yAxisValue);
            MaxHash.insert(yAxisValue,xAxisKey);
            MaxAreaPoints = MaxVector.count();//极大值区域点个数
        }
        else
        {//处理极小值区域
            MinAreaPoints =0;
            if(MaxVector.size()!=0)
            {
                //处理
                getMaxValueIndex(MaxVector);//get Max and MaxIndex
                ui->MaxValueLineEdit->setText(QString::number(Max,'f',3)+ " mmHg");//最大值
#if 0
                TIME = MaxHash.value((int)Max)-TIME;
                //                qDebug()<<"周期内极大值:"<<Max ;
                ui->FrequenceLineEdit->setText(QString::number(60/TIME,'f',3)+ " cycle/min");//CPM
                TIME = MaxHash.value((int)Max);
#endif
                MaxVector.clear();//处理清空极大值区域容器
                MaxHash.clear();
            }
            else
            {
                ;//如果极大值容器为空不做任何处理
            }
            MinVector.append(yAxisValue);
            MinHash.insert(yAxisValue,xAxisKey);
            MinAreaPoints = MinVector.count();//极小值区域点个数
        }
        ui->DetaPressureLineEdit->setText(QString::number(Max-Min,'f',3)+ " mmHg");//△P =mmHg
        //==============================================================
    }
    else
    {
        ;//如果standardLine<0，表示为获取样品，不做任何处理
    }
#endif
    //======================实时曲线绘制============================
    static double lastPointKey = 0.0;
    if(key - lastPointKey >=0.001)//间隔点
    {
        ui->qCustomPlot->graph(0)->addData(xAxisKey,yAxisValue);
        ui->qCustomPlot->graph(0)->removeDataBefore(key-8);
        //        ui->qCustomPlot->graph(0)->rescaleValueAxis();//坐标值自动缩放
        lastPointKey = key;
    }
    //设置本地大气压基线
    ui->qCustomPlot->graph(3)->addData(xAxisKey-8,Atmospheric);
    ui->qCustomPlot->graph(3)->addData(xAxisKey+0.25,Atmospheric);

    ui->qCustomPlot->xAxis->setRange(key+0.25,8,Qt::AlignRight);//x轴8大格每小格0.25*  移动x坐标
    ui->qCustomPlot->replot();//重绘曲线
    index++;
}
void AmerdaWidget::setyAxisValue(double value)
{
    yAxisValue = value;
}

void AmerdaWidget::setParametersValue(double Max,
                                      double Min, double cpm, double TriangleP)
{
    ui->MaxValueLineEdit->setText(tr("%1").arg(QString::number(Max,'f',3))+tr(" mmHg"));
    ui->MinValueLineEdit->setText(tr("%1").arg(QString::number(Min,'f',3))+tr(" mmHg"));
    ui->FrequenceLineEdit->setText(tr("%1").arg(QString::number(cpm,'f',3))+tr(" cycle/min"));
    ui->DetaPressureLineEdit->setText(tr("%1").arg(QString::number(TriangleP,'f',3))+tr(" mmHg"));
}
/**
  * @brief AmerdaLogSave
  * 保存log日志文档
  */
bool AmerdaWidget::AmerdaLogSave()
{
    //获取测试数据值以及状态 操作
    /**
     * 格式化日志文件
     */
    QString logName=NULL;

    if(UDISK_STATUS==0||UDISK_STATUS==1)
    {//UDISK mounted.
#ifdef iMX6
        logName = "/mnt/usb/Ameda_data/ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".log";
#else
        logName = "/media/root/JHONCONAL/Ameda_data/ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".log";
#endif
        //        qDebug()<<"Log File Path: "+logName;
    }
    else
    {     //UDISK umounted.
        logName = "./ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".log";
        //        qDebug()<<"Log File Path: "+logName;
    }
    text="=====================================================================\n";
    text.append("***                         AMEDA  Inspection Log                 ***\n");
    text.append("***                                                               ***\n");
    text.append("***  INTERNATIONAL STANDARD ATMOSPHERE:1Mpa≈760mmHg              ***\n");
    text.append("***  LOG_TIME :  "+QDateTime::currentDateTime().toString("hh:mm:ss MM/dd/yyyy")+
                " UTC                          ***\n");
    text.append("***  COPYRIGHT :  Copyright(c)2016 ebulent(shenzhen)Co.,LTD.      ***\n");
    text.append("***  PRODUCT :  Ameda                                             ***\n");
    text.append("***  COMPANY :  ebulent                                           ***\n");
    text.append("***  DESCRIPTION :  qian.yang@ebulent.com.cn                         ***\n");
    text.append("***                                                               ***\n");
    text.append("=====================================================================\n");

    text.append("------>Speed Switch : "+tr("<%1").arg(ui->comboBox->currentText())+">\n");
    text.append("------>Suction Switch : "+tr("<%1").arg(ui->comboBox_2->currentText())+">\n");
    text.append("------>Pumping Numbers : "+tr("<%1").arg(ui->comboBox_3->currentText())+">\n");
    text.append("Parameters Output:\n");
    text.append("------>MaxValue in at least 3 minutes : "+tr("<%1").arg(ui->MaxValueLineEdit->text())+">\n");
    text.append("------>MinValue in at least 3 minutes : "+tr("<%1").arg(ui->MinValueLineEdit->text())+">\n");
    text.append("------>Period/Frequency :"+tr("<%1").arg(ui->FrequenceLineEdit->text())+">\n");
    text.append("=====================================================================\n");
    //    text.append("------>测试通过状态 ："+tr("%1").arg(ISPASS));
    //     text.append("------>TESTING RESULT ："+tr("%1").arg(ISPASS));
    //保存日志
    bool result = help->WriteSaveFile(logName,text);
    if(result)
    {
        return true;
    }
    return false;
}
/**
 * @brief AmerdaCruveSave
 * 获取压力曲线文档
 */
bool AmerdaWidget::AmerdaCruveSave()
{
    QString pdfName=NULL,bmpName=NULL;
    if(UDISK_STATUS==0||UDISK_STATUS==1)
    {//UDISK mounted.
#ifdef iMX6
        pdfName = "/mnt/usb/Ameda_data/ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".pdf";
        bmpName = "/mnt/usb/Ameda_data/ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".bmp";
#else
        pdfName = "/media/root/JHONCONAL/Ameda_data/ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".pdf";
        bmpName = "/media/root/JHONCONAL/Ameda_data/ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".bmp";
#endif
        //        qDebug()<<"Pdf File Path: "+pdfName;
    }
    else
    {
        pdfName = "./ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".pdf";
        //        qDebug()<<"Pdf File Path: "+pdfName;
        bmpName = "./ameda-"+QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss")+".bmp";
        //        qDebug()<<"Bmp File Path: "+bmpName;
    }
    /*
     *保存pdf/bmp文档
    */
    if(ui->qCustomPlot->saveBmp(bmpName,1024,768,1.0))
    {//保存为bmp文档
        //    if(ui->qCustomPlot->savePdf(pdfName,false,1024,768,"null","ameda test")){//保存为pdf文档
        return true;
    }
    else
    {
        return false;
    }
    return false;
}
/**
 * @brief AmerdaWidget::paintEvent
 * 绘图事件
 */
void AmerdaWidget::paintEvent(QPaintEvent *)
{
}
/**
 * @brief AmerdaWidget::dlv015aSensorSlot
 * @param mmHg
 * 链接接受DLV015A压力传感器数据槽函数
 */
void AmerdaWidget::dlv015aSensorSlot(double mmHg)
{
    //    qDebug()<<"mmHg = "<<mmHg;
    setyAxisValue(mmHg);
    ui->lineEdit->setText(QString::number(mmHg,'f',3)+" mmHg");
}

void AmerdaWidget::dlv015aSensorSlot(double time, double mmHg)
{
    if(standardLine>0)
    {
        if(mmHg > standardLine)
        {//处理极大值区域
            if(MinVector.size()!=0)
            {
                //处理
                getMinValueIndex(MinVector);//get Min and MinIndex;
                ui->MinValueLineEdit->setText(QString::number(Min,'f',3)+ " mmHg");

#if 0
                TIME2 = (ValleyTimeVector.last()+ValleyTimeVector.first())/2.0-TIME2;
                // qDebug()<<"周期内极大值:"<<Max ;
                ui->FrequenceLineEdit->setText(QString::number(60/TIME2,'f',3)+ " cycle/min");//CPM
                TIME2 = (ValleyTimeVector.last()+ValleyTimeVector.first())/2.0;
#else
                TIME =(ValleyTimeVector.last()+ValleyTimeVector.first())/2.0-TIME;
                if(cycleDelay ==2)
                {
                     ui->FrequenceLineEdit->setText(QString::number(60/(TIME_AVEG/cycleDelay),'f',3)+ " cycle/min");//CPM
                     cycleDelay =0;
                     TIME_AVEG = 0;
                }
                TIME_AVEG +=TIME;
                TIME = (ValleyTimeVector.last()+ValleyTimeVector.first())/2.0;
                cycleDelay++;
#endif
                MinVector.clear();//处理清空极小值区域容器
                ValleyTimeVector.clear();
                MinHash.clear();
                //qDebug()<<"周期内极小值: "<<Min;
            }
            else
            {//
                ;//如果极小值容器为空不做任何处理
            }
            MaxVector.append(mmHg);
            CrestTimeVector.append(time);
            MaxHash.insert(mmHg,time);
        }
        else
        {//处理极小值区域
            if(MaxVector.size()!=0)
            {
                //处理
                getMaxValueIndex(MaxVector);//get Max and MaxIndex
                ui->MaxValueLineEdit->setText(QString::number(Max,'f',3)+ " mmHg");//最大值
#if 0
                TIME = (CrestTimeVector.last()+CrestTimeVector.first())/2.0-TIME;
                // qDebug()<<"周期内极大值:"<<Max ;
                ui->FrequenceLineEdit->setText(QString::number(60/TIME,'f',3)+ " cycle/min");//CPM
                TIME = (CrestTimeVector.last()+CrestTimeVector.first())/2.0;
#endif
                MaxVector.clear();//处理清空极大值区域容器
                CrestTimeVector.clear();
                MaxHash.clear();
            }
            else
            {
                ;//如果极大值容器为空不做任何处理
            }
            MinVector.append(mmHg);
            ValleyTimeVector.append(time);
            MinHash.insert(mmHg,time);
        }
        ui->DetaPressureLineEdit->setText(QString::number(Max-Min,'f',3)+ " mmHg");//△P =mmHg
        //==============================================================
    }
    else
    {
        ;//如果standardLine<0，表示为获取样品，不做任何处理
    }
}

void AmerdaWidget::reCheckGuideSolt(bool reCheckGuide)
{
    isReGuide = reCheckGuide;
}

void AmerdaWidget::sampleEndSlot()
{
    this->sampling = false;
    this->onceDeal = true;
    sampleTimer->stop();
    //disconnect(sampleTimer,SIGNAL(timeout()),this,SLOT(sampleEndSlot()));
}
/**
 * @brief AmerdaWidget::on_TestButton_clicked
 * 启动测试
 */
void AmerdaWidget::on_TestButton_clicked()
{
    if(isStopTesting)
    {//关闭
        //开启读取dlv015a设备线程信号与槽函数
        disconnect(amerda,SIGNAL(dlv015aSensorSignal(double)),
                           this,SLOT(dlv015aSensorSlot(double)));
        disconnect(updateTimer,SIGNAL(timeout()),
                   this,SLOT(RealTimeDataSlot()));//关闭数据停止绘制曲线
        updateTimer->stop();
        disconnect(sampleTimer,SIGNAL(timeout()),this,SLOT(sampleEndSlot()));
        disconnect(amerda,SIGNAL(dlv015aSensorSignal(double,double)),
                        this,SLOT(dlv015aSensorSlot(double,double)));
        if(isEnglish)
        {
            ui->TestButton->setText("Start");
        }
        else
        {
            ui->TestButton->setText("启动");
        }
        //停止时使能suction 和 pumping两个combox
        //ui->comboBox->setEnabled(true);
        //ui->comboBox_2->setEnabled(true);
        //ui->comboBox_3->setEnabled(true);
        //==========================================================
        //重绘获取波峰波谷基线
        setStandardLine(Min,Max);
        xAxisCurrentTime=QDateTime::currentDateTime().toMSecsSinceEpoch()/1000.0;
        ui->qCustomPlot->graph(1)->addData(xAxisCurrentTime-8,LowerLine);
        ui->qCustomPlot->graph(2)->addData(xAxisCurrentTime-8,UpperLine);
        ui->qCustomPlot->graph(1)->addData(xAxisCurrentTime+0.25,LowerLine);
        ui->qCustomPlot->graph(2)->addData(xAxisCurrentTime+0.25,UpperLine);
        ui->qCustomPlot->replot();
        //==========================================================
        //空载校准本地大气压强DLV015 Normal Work
        if(ui->comboBox_2->currentIndex()==0
                &&ui->checkBox->isChecked()&&amerda->dlv015_fd>0)
        {
            Atmospheric = sampleAVG;
            QString text = tr("%1").arg(Atmospheric);
            qDebug()<<"设置本地大气压值"<<text;
            bool result;
            result= help->writeDoubleContentToFile(text);
            if(result==true)
            {//设置本地大气压值successed.
                QMessageBox::information(NULL,"Check Local Atmospheric Pressure Status",
                                         "\nGet local atmospheric pressure successed.");
                ui->checkBox->setChecked(false);
            }
            else
            {//设置本地大气压值failed.
                QMessageBox::critical(NULL,"Check Local Atmospheric Pressure Status",
                                      "\nGet local atmospheric pressure failed.");
            }
        }
        else if (amerda->dlv015_fd<=0)
        {
            QMessageBox::critical(NULL,"DLV015 Sersor Connect Status ",
                                  "\nDLV015 sensor  failed to connect .");
        }
        //===========================================================
        index = 0;
        sampling = false;
        standardLine = -1;
    }
    else
    {//启动
        connect(amerda,SIGNAL(dlv015aSensorSignal(double)),
                        this,SLOT(dlv015aSensorSlot(double)));

        connect(sampleTimer,SIGNAL(timeout()),this,SLOT(sampleEndSlot()));
        sampleTimer->start(2000);
        connect(updateTimer,SIGNAL(timeout()),this,SLOT(RealTimeDataSlot()));
        updateTimer->start();
        connect(amerda,SIGNAL(dlv015aSensorSignal(double,double)),
                        this,SLOT(dlv015aSensorSlot(double,double)));
        if(isEnglish)
        {
            ui->TestButton->setText("Stop");
        }
        else
        {
            ui->TestButton->setText("停止");
        }
        //暂停/停止时清除StandardLine曲线点数据
        ui->qCustomPlot->graph(1)->clearData();
        ui->qCustomPlot->graph(2)->clearData();
        //工作时屏蔽suction 和 pumping两个combox
        //ui->comboBox->setEnabled(false);
        //ui->comboBox_2->setEnabled(false);
        //ui->comboBox_3->setEnabled(false);
        //重置参数
        setParametersValue(0,0,0,0);
    }
    isStopTesting = !isStopTesting;
}
/**
 * @brief AmerdaWidget::on_SaveButton_clicked
 * 保存日志文件
 */
void AmerdaWidget::on_SaveButton_clicked()
{
    /**
     * @brief AmerdaLogSave
     * 保存测试日志文档log
     * 文件保存格式："ameda-2016-08-04-15-06-32.log"
     * ameda-year-month-day-hour-min-mesc.log
     */
    bool isLog,isPdf;
    isLog = AmerdaLogSave();
    /**
     * @brief AmerdaCruveSave
     * 保存压力曲线文档pdf/bmp  路径：app运行路径下
     * 文件保存格式："ameda-2016-08-04-15-06-32.pdf/.bmp"
     * ameda-year-month-day-hour-min-mesc.pdf/.bmp
     */
    isPdf = AmerdaCruveSave();
    if(isLog&&isPdf)
    {
        QMessageBox::about(NULL,"SAVE AMEDA DATA","save all Ameda data sussess.");
    }
    else if (isLog==true||isPdf==false)
    {
        QMessageBox::about(NULL,"SAVE AMEDA DATA","save Ameda Log sussess, Ameda Cruve failed.");
    }
    else if (isLog==false||isPdf==true)
    {
        QMessageBox::about(NULL,"SAVE AMEDA DATA","save Ameda Cruve sussess, Ameda Log failed.");
    }
    else
    {
        QMessageBox::about(NULL,"SAVE AMEDA DATA","save all Ameda data failed.");
    }
}
/**
 * @brief AmerdaWidget::SystemTimeSlot
 * 系统时间显示
 */
void AmerdaWidget::SystemTimeSlot()
{
    ui->TimeLabel->setText(QDateTime::currentDateTime().toString("dd/MM/yyyy hh:mm:ss"));
}

int AmerdaWidget::UDiskDetection()
{
    QFileInfoList procList,dirList;
#ifdef iMX6
    QDir procDir("/proc/scsi/usb-storage/");
    QDir dir("/mnt/usb/");
#else
    QDir procDir("/proc/scsi/usb-storage/");
    QDir dir("/root/Desktop/");
#endif
    //检测/proc/scsi/usb-storage/  /mnt/usb/ 目录
    procDir.setFilter(QDir::NoDotAndDotDot|QDir::Dirs|QDir::Files);
    dir.setFilter(QDir::NoDotAndDotDot|QDir::Dirs|QDir::Files);
    procList = procDir.entryInfoList();
    dirList    = dir.entryInfoList();

    if(procList.size()==0)
    {
        UDISK_STATUS = -1;
        qDebug()<<"not mount the disk.";
    }
    else
    {
        if(dirList.size()==0)
        {
            UDISK_STATUS = -1;
        }
        else
        {//exist the udisk "/mnt/usb/" and is not null
            QDir amedaDir("/mnt/usb/Ameda_data");
            if(amedaDir.exists())
            {//"Ameda_data"
                UDISK_STATUS = 0;
            }
            else
            {
                system("mkdir   /mnt/usb/Ameda_data");
                UDISK_STATUS = 1;
            }
        }
    }
    qDebug()<<"UDISK_STATUS ="<<UDISK_STATUS ;
    return UDISK_STATUS ;
}

void AmerdaWidget::SLEEP(int ms)
{
    QTime dieTime = QTime::currentTime().addMSecs(ms);
    while ( QTime::currentTime() < dieTime )
    {
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
    }
}
//get the max index of the vector
int AmerdaWidget::getMaxValueIndex(QVector<double> vector)
{
    double maxValue,temp;
    int index;
    //    qDebug()<<"Max容器大小:"<<vector.size();
    if(vector.size()<1)
    {//vector为空时返回-1
        return -1;
    }
    else
    {
        temp = vector.at(0);
        for(int i=0;i<vector.size();i++)
        {
            if(temp<=vector.at(i))
            {
                temp = vector.at(i);
            }
            else
            {
                maxValue = temp;
            }
        }
        maxValue = temp;
    }
    Max = maxValue;
    index =  vector.indexOf(maxValue);
    return  index;
}
//get the min index of the vector
int AmerdaWidget::getMinValueIndex(QVector<double> vector)
{
    double minValue,temp;
    int index;
    //    qDebug()<<"Min容器大小:"<<vector.size();
    if(vector.size()<1)
    {//vector为空时返回-1
        return -1;
    }
    else
    {
        temp = vector.at(0);
        for(int i=0;i<vector.size();i++)
        {
            if(temp>=vector.at(i))
            {
                temp = vector.at(i);
            }
            else
            {
                minValue = temp;
            }
        }
        minValue = temp;
    }
    Min = minValue;
    index =  vector.indexOf(minValue);
    return  index;
}

double AmerdaWidget::getMaxOrMinValue(
        QVector<double> vector, bool MaxOrMin)
{
    double  temp = 0.0,Max=0.0,Min=0.0;
    int i=0,j=0;
    if(MaxOrMin)
    {//Max value设置返回最大值
        if(vector.size()<1)
        {//vector为空时返回-1
            return -1;
        }
        else
        {
            temp = vector.at(0);
            for(i=0;i<vector.size();i++)
            {
                if(temp<=vector.at(i))
                {
                    temp = vector.at(i);
                }
                else
                {
                    Max = temp;
                }
            }
            Max = temp;
        }
        return Max;
    }
    else
    {//Min value设置返回最小值
        if(vector.size()<1)
        {//vector为空返回-1
            return -1;
        }
        else
        {
            temp = vector.at(0);
            for(j=0;j<vector.size();j++)
            {
                if(temp>=vector.at(j))
                {
                    temp = vector.at(j);
                }
                else
                {
                    Min =temp;
                }
            }
            Min = temp;
        }
        return Min;
    }
    return -1;
}
/**
 * @brief AmerdaWidget::setStandardLine
 * @param upper
 * 设置标准线
 */
void AmerdaWidget::setStandardLine(double lower, double upper)
{
    UpperLine = upper;
    LowerLine = lower;
}
/**
 * @brief AmerdaWidget::getSampleData
 * @param vector
 * 获取样品数据包括最大值，最小值，平均值
 */
void AmerdaWidget::getSampleData(QVector<double> vector)
{
    qDebug()<<"样品容量:"<<vector.count();
    double temp_max,temp_min,sum=0;
    sampleCount = vector.size();
    if(vector.size()<1)
    {//vector为空时返回-1
        return ;
    }
    else
    {
        temp_max = vector.at(0);
        temp_min = vector.at(0);
        for(int i=0;i<vector.size();i++)
        {
            sum+=vector.at(i);//求和
            if(temp_max <=vector.at(i))
            {
                temp_max = vector.at(i);
            }
            else
            {
                sampleMax = temp_max ;
            }
            if(temp_min>=vector.at(i))
            {
                temp_min=vector.at(i);
            }
            else
            {
                sampleMin = temp_min;
            }
        }
        sampleMax = temp_max ;//样品最大值
        sampleMin =temp_min;//样品最小值
        sampleSum = sum;
    }
    sampleAVG = sampleSum/vector.size();//样品平均值
    //     qDebug()<<"sample_Sum: "<<sampleSum;
    //     qDebug()<<"sample_count: "<<sampleCount;
    //     qDebug()<<"sample_Averge: "<<sampleAVG;
    //     qDebug()<<"sample_Max: "<<sampleMax;
    //     qDebug()<<"sample_Min: "<<sampleMin;
}

void AmerdaWidget::on_LogButton_clicked()
{
    if(isPreview)
    {
        edit->setGeometry(width/2-300,height/2-200,600,400);
        if(text==NULL)
        {
        }
        else
        {
            edit->setText(text);
            edit->show();
        }
    }
    else
    {
        edit->close();
    }
    isPreview = !isPreview;
}

void AmerdaWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->type()==QEvent::MouseButtonPress)
    {
        edit->close();
        event->accept();
    }
}

void AmerdaWidget::on_comboBox_currentIndexChanged(int index)
{
    Q_UNUSED (index)
    switch (ui->comboBox->currentIndex())
    {
    case 0:
        if(ui->comboBox_3->currentIndex()==0)
        {//单奶瓶
            ui->SpeedAreaLineEdit->setText("26.4≤CPM≤30");
        }
        else
        {//双奶瓶
            ui->SpeedAreaLineEdit->setText("26.4≤CPM≤30");
        }
        break;
    case 1:
        if(ui->comboBox_3->currentIndex()==0)
        {//单奶瓶
            ui->SpeedAreaLineEdit->setText("35.2≤CPM≤40");
        }
        else
        {//双奶瓶
            ui->SpeedAreaLineEdit->setText("35.2≤CPM≤40");
        }
        break;
    case 2:
        if(ui->comboBox_3->currentIndex()==0)
        {//单奶瓶
            ui->SpeedAreaLineEdit->setText("44≤CPM≤50");
        }
        else
        {//双奶瓶
            ui->SpeedAreaLineEdit->setText("44≤CPM≤50");
        }
        break;
    case 3:
        if(ui->comboBox_3->currentIndex()==0)
        {//单奶瓶
            ui->SpeedAreaLineEdit->setText("52.8≤CPM≤60");
        }
        else
        {//双奶瓶
            ui->SpeedAreaLineEdit->setText("52.8≤CPM≤60");
        }
        break;
    default:
        break;
    }
}

void AmerdaWidget::on_comboBox_2_currentIndexChanged(int index)
{
    Q_UNUSED (index)
    switch (ui->comboBox_2->currentIndex())
    {
    case 0:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("△P=0 mmHg");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("△P=0 mmHg");
        }
        break;
    case 1:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P <75");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P <75");
        }
        break;
    case 2:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        break;
    case 3:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        break;
    case 4:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        break;
    case 5:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        break;
    case 6:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        break;
    case 7:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        break;
    case 8:
        if(isSingal)
        {
            ui->PressureAreeaLineEdit->setText("243≤△P≤297");
        }
        else
        {
            ui->PressureAreeaLineEdit->setText("175.5≤△P≤214.5");
        }
        break;
    default:
        break;
    }
}

void AmerdaWidget::on_comboBox_3_currentIndexChanged(int index)
{
    Q_UNUSED (index);
    switch (ui->comboBox_3->currentIndex())
    {
    case 0://singal
        isSingal = true;
        if(ui->comboBox_2->currentIndex()==0)
        {
            ui->PressureAreeaLineEdit->setText("△P=0 mmHg");
        }
        else if (ui->comboBox_2->currentIndex()==1)
        {
            ui->PressureAreeaLineEdit->setText("0<△P＜75");
        }
        else if (ui->comboBox_2->currentIndex()==2)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else if (ui->comboBox_2->currentIndex()==3)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else if (ui->comboBox_2->currentIndex()==4)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else if (ui->comboBox_2->currentIndex()==5)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else if (ui->comboBox_2->currentIndex()==6)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤297");
        }
        else if (ui->comboBox_2->currentIndex()==7)
        {
            ui->PressureAreeaLineEdit->setText("50<△P≤297");
        }
        else if (ui->comboBox_2->currentIndex()==8)
        {
            ui->PressureAreeaLineEdit->setText("243≤△P≤297");
        }
        //设置单奶瓶CPM
        if(ui->comboBox->currentIndex() ==0)
        {
            ui->SpeedAreaLineEdit->setText("26.4≤CPM≤30");
        }
        else if (ui->comboBox->currentIndex() ==1)
        {
            ui->SpeedAreaLineEdit->setText("35.2≤CPM≤40");
        }
        else if (ui->comboBox->currentIndex() ==2)
        {
            ui->SpeedAreaLineEdit->setText("44≤CPM≤50");
        }
        else if (ui->comboBox->currentIndex() ==3)
        {
            ui->SpeedAreaLineEdit->setText("52.8≤CPM≤60");
        }
        break;
    case 1:  //dual 双奶瓶
        isSingal = false;
        if(ui->comboBox_2->currentIndex()==0)
        {
            ui->PressureAreeaLineEdit->setText("△P=0 mmHg");
        }
        else if (ui->comboBox_2->currentIndex()==1)
        {
            ui->PressureAreeaLineEdit->setText("0<△P＜75");
        }
        else if (ui->comboBox_2->currentIndex()==2)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        else if (ui->comboBox_2->currentIndex()==3)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        else if (ui->comboBox_2->currentIndex()==4)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        else if (ui->comboBox_2->currentIndex()==5)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        else if (ui->comboBox_2->currentIndex()==6)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        else if (ui->comboBox_2->currentIndex()==7)
        {
            ui->PressureAreeaLineEdit->setText("0<△P≤214.5");
        }
        else if (ui->comboBox_2->currentIndex()==8)
        {
            ui->PressureAreeaLineEdit->setText("175.5≤△P≤214.5");
        }
        //设置双奶瓶CPM
        if(ui->comboBox->currentIndex() ==0)
        {
            ui->SpeedAreaLineEdit->setText("26.4≤CPM≤30");
        }
        else if (ui->comboBox->currentIndex() ==1)
        {
            ui->SpeedAreaLineEdit->setText("35.2≤CPM≤40");
        }
        else if (ui->comboBox->currentIndex() ==2)
        {
            ui->SpeedAreaLineEdit->setText("44≤CPM≤50");
        }
        else if (ui->comboBox->currentIndex() ==3)
        {
            ui->SpeedAreaLineEdit->setText("52.8≤CPM≤60");
        }
        break;
    default:
        break;
    }
}

void AmerdaWidget::on_pushButton_clicked()
{
    system("reboot");
}

void AmerdaWidget::on_checkBox_clicked()
{
    if(ui->checkBox->isChecked())
    {
        //qDebug()<<"1----------------->";
        atmIndex = new AtmIndexWidget();
        connect(atmIndex,SIGNAL(reCheckGuideSignal(bool)),this,SLOT(reCheckGuideSolt(bool)));
        if(isReGuide==true)
        {
            //qDebug()<<"2----------------->";
            atmIndex->resize(width,height);
            atmIndex->show();
        }
        else
        {
            //qDebug()<<"3----------------->";
        }
    }
    else
    {
        //qDebug()<<"4----------------->";
    }
}
