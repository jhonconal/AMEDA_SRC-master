/**************************************************************
**This is available in all editors.
**Copyright(c)2016 ebulent(shenzhen)Co.,LTD. All Right Reserved.
**Contact: http://www.ebulent.com.cn/
**Author: qain.yang
**Postion: Softwere engineer
**email:qian.yang@ebulent.com.cn jhonconal@outlook.com
**This app sourcecode are for ameda test
**
***************************************************************/
#ifndef AMERDAWIDGET_H
#define AMERDAWIDGET_H

#include <QWidget>
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include <QDate>
#include <QPen>
#include <QFont>
#include <QPainter>
#include <QPaintEvent>
#include <QMessageBox>
#include <QMouseEvent>
#include <QDesktopWidget>
#include <QtCore>
#include <QtGui>
#include <QMap>
#include<QHash>
#include<qmath.h>
#include<pthread.h>//unix线程头文件
#include"dirent.h"
#include <unistd.h>//获取进程ID
#include<queue>//队列STL
#include "qcustomplot.h"
#include "helper.h"
#include "amerdathread.h"
#include "atmindexwidget.h"

//#define DESKTOP
#define iMX6

namespace Ui {
class AmerdaWidget;
}

class AmerdaWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AmerdaWidget(QWidget *parent = 0);
    ~AmerdaWidget();
    /**
     * @brief init
     * 初始化环境
     */
    void init();
    /**
     * @brief setLanguage
     * @param language
     * @return
     * 设置程序语言
     */
    bool setLanguage(QString language);
    /**
     * @brief initAmerdaCruve
     * 初始化压力曲线面板
     */
    void initAmerdaCruve();
    /**
     * @brief initParametersValue
     * 初始化参数值
     */
    void initParametersValue();
    /**
     * @brief setyAxisValue
     * @param value
     * 设置y轴坐标值
     */
    void setyAxisValue(double value);
    /**
     * @brief setParametersValue
     * @param Max
     * @param Min
     * @param Frquency
     * @param TriangleP
     * @param Status
     * 设置获取采集的参数值
     */
    void setParametersValue(double Max,double Min
                            ,double cpm,double TriangleP);
    /**
     * @brief AmerdaLogSave
     * 测试日志保存
     */
    bool AmerdaLogSave();
    /**
     * @brief AmerdaCruveSave
     * @return
     * 测试压力曲线保存
     */
    bool AmerdaCruveSave();
    /**
     * @brief UDiskSpecialFileDetection
     * @return default -1 未检测到U盘
     * 0;//检测到U盘并且里面包含Ameda_data文件夹
     * 1;//检测到U盘文件、但未发现Ameda_data文件夹、创建这个文件夹
     * U盘挂载检测函数
     */

    int UDiskDetection();
    /**
     * @brief SLEEP
     * @param ms  睡眠时间
     * 睡眠函数
     */
    void SLEEP(int ms);
    /**
     * @brief getMaxValueIndex
     * @param vector
     * @return   max value index of the QVector<mmHg>
     */
    int getMaxValueIndex(QVector<double>vector);
    int getMinValueIndex(QVector<double>vector);
    /**
     * @brief getMaxOrMinValue
     * @param vector     数据点容器
     * @param MaxOrMin  判断获取最大值/最小值
     * @return
     * 获取最大值和最小值
     */
    double getMaxOrMinValue(QVector<double>vector,bool MaxOrMin);
    /**
     * @brief setStandardLine
     * @param lower   下线
     * @param upper    上线
     * 设置动态标准线
     */
    void setStandardLine(double lower,double upper);
    /**
     * @brief getSampleData
     * @param vector   样品容器
     * 获取样品数据
     */
    void getSampleData(QVector<double>vector);

protected:
    void paintEvent(QPaintEvent*);
    //=============================================
public slots:
    void  dlv015aSensorSlot(double mmHg);
    void  dlv015aSensorSlot(double time,double mmHg);
    void  reCheckGuideSolt(bool reCheckGuide);
    void  sampleEndSlot();//终止采样槽函数
private slots:
    /**
     * @brief on_TestButton_clicked
     * 启动选择档位测试槽函数
     */
    void on_TestButton_clicked();
    /**
     * @brief on_SaveButton_clicked
     * 保存日志槽函数
     */
    void on_SaveButton_clicked();
    /**
     * @brief RealTimeDataSlot
     * 实时数据槽函数
     */
    void RealTimeDataSlot();
    /**
     * @brief SystemTimeSlot
     * 系统实时时间
     */
    void SystemTimeSlot();

    /**
     * @brief on_LogButton_clicked
     * 日志预览
     */
    void on_LogButton_clicked();

    /**
     * @brief on_comboBox_currentIndexChanged
     * @param index
     * 速度切换槽函数
     */
    void on_comboBox_currentIndexChanged(int index);
    /**
     * @brief on_comboBox_2_currentIndexChanged
     * @param index
     * 吸力切换槽函数
     */
    void on_comboBox_2_currentIndexChanged(int index);
    /**
     * @brief on_comboBox_3_currentIndexChanged
     * @param index
     * 单双奶瓶切换槽函数
     */
    void on_comboBox_3_currentIndexChanged(int index);

    /**
     * @brief on_pushButton_clicked
     * 重启系统槽函数
     */
    void on_pushButton_clicked();
    /**
     * @brief on_checkBox_clicked
     * check local atm 槽函数
     */
    void on_checkBox_clicked();

protected:
    void mousePressEvent(QMouseEvent *event);

private:
    Ui::AmerdaWidget *ui;

    double    yAxisValue,xAxisKey;
    int       width,height;//获取显示器长宽
    double    UpperLine,LowerLine;//曲线上下限

    bool      isEnglish,isPreview,isSingal,isStopTesting;//是否预览  //是否为单奶 //termirate the testing or not
    int       UDISK_STATUS;//U Disk状态

    QTimer          *updateTimer,*systemTimer,*sampleTimer;//系统时间计时器 //采样计时器
    Helper          *help;
    AmerdaThread    *amerda;
    AtmIndexWidget  *atmIndex;
    QDesktopWidget  *desktop;
    QTextEdit       *edit;//预览文本框
    QString         text ;         //log save QString
    //==================
    QString       logCache;//日志缓存

    double   xAxisCurrentTime,Atmospheric;//大气压
    bool     isReGuide,sampling,onceDeal;//是否开启引导界面 //是否正在采样 //处理一次标志
    int      index;//插入vector标志
    double   Max,Min,CPM,TriangleP; //单位周期内最大值、最小值 //TriangleP=△P
    double   TIME,TIME2,TIME_AVEG;
    //===================样品采样值
    QVector<double>  MaxVector,MinVector,sampleVector;//单位周期内极大值处于区域容器//单位周期内极小值处于区域容器//样品容器
    QVector<double>  CrestTimeVector,ValleyTimeVector;//波峰/波谷区域 各点时间集合
    QHash<int,double>MaxHash,MinHash;
    double standardLine;//基准线
    double sampleSum,sampleAVG,sampleMax,sampleMin,sampleCount;//样品总和//样品平均值//样品最大值//样品最小值//样品数量
    int cycleDelay;//多少周期更新一次显示
};

#endif // AMERDAWIDGET_H
