#include "atmindexwidget.h"
#include "ui_atmindexwidget.h"

AtmIndexWidget::AtmIndexWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AtmIndexWidget)
{
    ui->setupUi(this);
    init();
    imageNameList<<"1.jpg"<<"2.jpg"<<"3.jpg"<<"4.jpg"<<"5.jpg";
    //ui->widget->setStyleSheet(QString("border-image: url(:/src/images/%1);").arg(imageNameList.at(index)));
    setWindowFlags(Qt::FramelessWindowHint);
}

AtmIndexWidget::~AtmIndexWidget()
{
    delete ui;
}

void AtmIndexWidget::init()
{
    reCheckGuide =true;
    index =0;
    MaxIndex= 4;
}

void AtmIndexWidget::on_PreButton_clicked()
{
    index--;
    if(index<=0)
    {
        ui->PreButton->setEnabled(false);
        index =0;
        ui->widget->setStyleSheet(QString("border-image: url(:/src/images/%1);").arg(imageNameList.at(index)));
    }
    if(index>0)
    {
        ui->PreButton->setEnabled(true);
        ui->widget->setStyleSheet(QString("border-image:url(:/src/images/%1);").arg(imageNameList.at(index)));
    }
}

void AtmIndexWidget::on_NextButton_clicked()
{
    index++;
    if(index==MaxIndex)
    {
        ui->PreButton->setEnabled(true);
        index =MaxIndex;
        ui->widget->setStyleSheet(QString("border-image:url(:/src/images/%1);").arg(imageNameList.at(index)));
    }
    if(index>0&&index<MaxIndex)
    {
        ui->PreButton->setEnabled(true);
        ui->widget->setStyleSheet(QString("border-image:url(:/src/images/%1);").arg(imageNameList.at(index)));
    }
    if(index>MaxIndex)
    {
        index =MaxIndex;
        ui->PreButton->setEnabled(true);
        ui->widget->setStyleSheet(QString("border-image:url(:/src/images/%1);").arg(imageNameList.at(index)));
        QMessageBox message(QMessageBox::Question, "Shutt Off The Guide ?", "\nDo you want to shutt off  this guide next time ?", QMessageBox::Yes | QMessageBox::No, NULL);
        if(message.exec() == QMessageBox::Yes)
        {
               qDebug()<<"Check status: YES";
               reCheckGuide = false;
        }else {
               qDebug()<<"Check status: No";
               reCheckGuide = true;
        }
        emit reCheckGuideSignal(reCheckGuide);
        this->close();
    }
}
