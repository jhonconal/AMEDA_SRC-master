#ifndef ATMINDEXWIDGET_H
#define ATMINDEXWIDGET_H

#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QList>
#include <helper.h>
namespace Ui {
class AtmIndexWidget;
}

class AtmIndexWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AtmIndexWidget(QWidget *parent = 0);
    ~AtmIndexWidget();
    bool reCheckGuide;//是否再次显示引导界面
    void init();

private slots:
    void on_PreButton_clicked();
    void on_NextButton_clicked();
signals:
    void reCheckGuideSignal(bool);
private:
    Ui::AtmIndexWidget *ui;
    Helper *helper;
    QList<QString>imageNameList;
    int index;
    int MaxIndex;
};

#endif // ATMINDEXWIDGET_H
