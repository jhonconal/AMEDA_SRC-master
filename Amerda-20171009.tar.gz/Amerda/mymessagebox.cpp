#include "mymessagebox.h"
#include "ui_mymessagebox.h"

MyMessageBox::MyMessageBox(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyMessageBox)
{
    ui->setupUi(this);
    this->mousePressed = false;
}

MyMessageBox::~MyMessageBox()
{
    delete ui;
}

void MyMessageBox::SetMessage(const QString &msg, int type)
{
    if (type == 0) {

    } else if (type == 1) {

    } else if (type == 2) {

    }
}

void MyMessageBox::mouseMoveEvent(QMouseEvent *e)
{
    if (mousePressed && (e->buttons() && Qt::LeftButton)) {
        this->move(e->globalPos() - mousePoint);
        e->accept();
    }
}

void MyMessageBox::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton) {
        mousePressed = true;
        mousePoint = e->globalPos() - this->pos();
        e->accept();
    }
}

void MyMessageBox::mouseReleaseEvent(QMouseEvent *)
{
     mousePressed = false;
}
